import { Property } from "../property";

export interface PropertiesResponse {
    properties:Property[];
}
