import { Province } from "../province";

export interface ProvincesResponse {
    provinces:Province[];
}
