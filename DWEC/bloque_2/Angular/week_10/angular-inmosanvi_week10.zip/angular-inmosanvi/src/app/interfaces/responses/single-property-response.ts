import { Property } from "../property";

export interface SinglePropertyResponse {
    property:Property;
}
