import { Town } from "../town";

export interface TownsResponse {
    towns:Town[];
}
